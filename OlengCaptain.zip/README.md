# Websocket-Python

## Cara Penggunaan
1. Buka terminal/cmd
2. Arahkah ke folder src
3. jalankan perintah 'python server.py'
4. jalankan perintah 'ngrok http 8000'

## Pembagian Tugas
- Taufikurrahman Anwar 13517074 : server.py
- Dandi Agus Maulana 13517077 : framing.py
- Muhammad Fikri Hizbullah 13517104 : handshake.py
